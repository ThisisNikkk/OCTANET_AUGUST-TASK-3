# Soptify-Web_page
This is the spotify web page website clone. Using html and css.
