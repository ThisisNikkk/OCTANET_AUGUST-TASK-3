# Spotify-clone website

## Set the favicon as icon in link :

```html
<link rel="icon" stylesheet="./Accets/logo.png" />
```

## Check the website layout and create the div accordingly.

- here i create the main div and inside main div i create the three sections
- 1. sidebar-section
- 2. main-content
- 3. music-player


## Universal Selector : used to give the font and all other parametrs
 
 - margin:0;
 - padding:0;
 - overflow:hidden; (to avoid the scrollabel things)